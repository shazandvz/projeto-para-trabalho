﻿namespace DevFreela.API.Models
{
    public class CreateSkillInputModel
    {
        public string Description { get; set; }
    }
}
