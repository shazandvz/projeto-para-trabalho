﻿namespace DevFreela.API.Models
{
    public class FreelanceTotalCostConfig
    {
        public decimal Minimum { get; set; }
        public decimal Maximum { get; set; }
    }
}
