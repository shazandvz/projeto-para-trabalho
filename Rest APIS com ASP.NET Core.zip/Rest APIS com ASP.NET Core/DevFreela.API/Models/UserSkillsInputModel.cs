﻿namespace DevFreela.API.Models
{
    public class UserSkillsInputModel
    {
        public int[] SkillIds { get; set; }
        public int Id { get; set; }
    }
}
